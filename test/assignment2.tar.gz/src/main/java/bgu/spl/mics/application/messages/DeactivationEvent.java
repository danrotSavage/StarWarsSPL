package main.java.bgu.spl.mics.application.messages;

import main.java.bgu.spl.mics.Event;

public class DeactivationEvent implements Event<Boolean> {
}
