package main.java.bgu.spl.mics.application.messages;

import main.java.bgu.spl.mics.Broadcast;

public class DeactivationBroadcast implements Broadcast {

}
