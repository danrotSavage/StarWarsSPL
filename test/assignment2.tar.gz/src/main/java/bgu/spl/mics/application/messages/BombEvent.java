package main.java.bgu.spl.mics.application.messages;

import main.java.bgu.spl.mics.Event;
import main.java.bgu.spl.mics.application.passiveObjects.Attack;

public class BombEvent implements Event<Attack> {
}
